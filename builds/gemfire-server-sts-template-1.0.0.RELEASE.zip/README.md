Spring Data Gemfire - Cache Server Template
================================================================================

This template demonstrates using Spring Data Gemfire to create a cache server as a standalone Java application with an embedded cache and a single region.

You can run the application by either

* running the "Main" class from within STS (Right-click on Main class --> Run As --> Java Application)
* or from the command line:
    - mvn package
    - mvn exec:java

--------------------------------------------------------------------------------

For help please take a look at the Spring Data Gemfire documentation:

http://www.springsource.org/spring-gemfire

