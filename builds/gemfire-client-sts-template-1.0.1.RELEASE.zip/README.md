Spring Data Gemfire - Client Template
================================================================================

This template demonstrates using Spring Data Gemfire in a standalone Java application with a cache client and a single client region with a simple CacheListener.

You can run the application by either

* running the "Main" class from within STS (Right-click on Main class --> Run As --> Java Application)
* or from the command line:
    - mvn package
    - mvn exec:java

--------------------------------------------------------------------------------

For help please take a look at the Spring Data Gemfire documentation:

https://spring.io/projects/spring-data-gemfire

