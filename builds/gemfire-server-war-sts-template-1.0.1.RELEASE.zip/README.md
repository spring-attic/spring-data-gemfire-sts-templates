Spring Data Gemfire - Cache Server War Template
================================================================================

This template demonstrates using Spring Data Gemfire to create a cache server that runs as a Java web application in a Servlet container with an embedded cache and a single region.
--------------------------------------------------------------------------------

For help please take a look at the Spring Data Gemfire documentation:

https://spring.io/projects/spring-data-gemfire

